﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbJenisPS.Items.AddRange(new string[] {
                "PS1",
                "PS2",
                "PS3",
                "PS4",
                "PS5"
            });
        }
        private int GetHargaPerjam(string jenisPS)
        {
            switch (jenisPS)
            {
                case "PS1":
                    return 5000;
                case "PS2":
                    return 10000;
                case "PS3":
                    return 15000;
                case "PS4":
                    return 20000;
                case "PS5":
                    return 25000;
                default:
                    return 0;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string nama = txtNama.Text;
            string jenisPS = cmbJenisPS.SelectedItem?.ToString();
            int durasi = int.Parse(txtDurasi.Text);
            int hargaPerJam = GetHargaPerjam(jenisPS);
            int total = durasi * hargaPerJam;
            dgvData.Rows.Add(nama, jenisPS, durasi, hargaPerJam, total);
        }
        private void btnHitung_Click(object sender, EventArgs e)
        {
            if (cmbJenisPS.SelectedItem == null || txtDurasi.Text == "")
            {
                MessageBox.Show("isi semua data terlebih dahulu.");
                return;
            }
            int durasi = int.Parse(txtDurasi.Text);
            int harga = GetHargaPerjam(cmbJenisPS.SelectedItem.ToString());
            int total = durasi * harga;
            MessageBox.Show($"Total bayar: Rp {total}", "info");
        }
        private void ClearFrom()
        {
            txtNama.Clear();
            txtDurasi.Clear();
            cmbJenisPS.SelectedIndex = -1;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtNama_TextChanged(object sender, EventArgs e)
        {

        }

    }
    }

